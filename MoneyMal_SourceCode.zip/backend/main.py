"""
Hybrid Sentinel — FastAPI Backend
Stateless REST API serving the merged forensics engine.
Serves the React frontend static build in production.
"""

import io
import json
import os

import pandas as pd
from fastapi import FastAPI, UploadFile, File, HTTPException, Depends
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, FileResponse
from fastapi.staticfiles import StaticFiles
from sqlalchemy.orm import Session
from sqlalchemy import desc

from backend.engine import ForensicsEngine
from backend.database import engine, get_db, Base
from backend.models import Transaction, Account, Alert
from pydantic import BaseModel
from typing import List
import datetime

# Create tables
Base.metadata.create_all(bind=engine)

class TransactionStream(BaseModel):
    transaction_id: str
    sender_id: str
    receiver_id: str
    amount: float
    timestamp: datetime.datetime

app = FastAPI(
    title="Hybrid Sentinel API",
    description="Money Muling Detection Engine — RIFT 2026",
    version="5.0.0",
)

# ---- CORS (allow all origins for universal deployment) ---- #
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/api/health")
async def health():
    return {"status": "ok", "engine": "Hybrid Sentinel v5"}


@app.post("/api/analyze")
async def analyze(file: UploadFile = File(...), db: Session = Depends(get_db)):
    """
    Accept a CSV file upload, push transactions to Postgres,
    and process anomalies incrementally.
    """
    if not file.filename.endswith(".csv"):
        raise HTTPException(status_code=400, detail="Only CSV files are accepted.")

    try:
        content = await file.read()
        df = pd.read_csv(io.BytesIO(content))
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Failed to parse CSV: {e}")

    # Removed slow one-by-one DB insertion to prevent timeouts on large datasets.
    # The forensics engine below processes the 'df' directly.
    pass

    forensics_engine = ForensicsEngine()
    try:
        # NOTE: load_data should ideally do incremental pulls bounded by Postgres
        forensics_engine.load_data(df)
    except ValueError as e:
        raise HTTPException(status_code=422, detail=str(e))

    result = forensics_engine.run_all()
    graph_data = forensics_engine.get_graph_data()

    return JSONResponse(content={
        "result": json.loads(json.dumps(result, default=str)),
        "graph": json.loads(json.dumps(graph_data, default=str)),
    })

@app.post("/api/stream")
async def stream_transaction(transactions: List[TransactionStream], db: Session = Depends(get_db)):
    """Ingest new transactions via REST and push to incremental queue."""
    for t in transactions:
        tx = Transaction(**t.dict())
        db.add(tx)
        
        # Here we'd push to Redis Streaming Queue
        # redis_client.xadd("transactions_stream", t.dict())
        
    try:
        db.commit()
    except Exception:
        db.rollback()
        raise HTTPException(status_code=400, detail="Transaction push failed.")
        
    return {"status": "ok", "inserted": len(transactions)}

@app.get("/api/alerts")
async def get_alerts(status: str = "PENDING", db: Session = Depends(get_db)):
    """Fetch stored database alerts for the frontend."""
    alerts = db.query(Alert).filter(Alert.status == status).order_by(Alert.created_at.desc()).limit(50).all()
    return {"alerts": [{"alert_id": a.alert_id, "account_id": a.account_id, "score": a.final_score, "explanation": a.explanation, "created_at": a.created_at.isoformat()} for a in alerts]}

@app.get("/api/graph/subgraph/{account_id}")
async def get_subgraph(account_id: str, k_hops: int = 2, db: Session = Depends(get_db)):
    """Extract a localized K-hop neighborhood graph representation for frontend performance."""
    # Dummy mock returning vis-network structure 
    # Real implementation requires recursive CTE tracking links depth > k_hops
    return {"nodes": [{"id": account_id, "label": account_id, "suspicion_score": 85}], "edges": []}


# ---- Serve frontend static build ---- #
FRONTEND_DIST = os.path.join(os.path.dirname(__file__), "..", "frontend", "dist")

if os.path.isdir(FRONTEND_DIST):
    # Mount static assets (JS, CSS, images)
    app.mount("/assets", StaticFiles(directory=os.path.join(FRONTEND_DIST, "assets")), name="assets")

    @app.get("/{full_path:path}")
    async def serve_spa(full_path: str):
        """Catch-all: serve index.html for SPA routing."""
        file_path = os.path.join(FRONTEND_DIST, full_path)
        if full_path and os.path.isfile(file_path):
            return FileResponse(file_path)
        return FileResponse(os.path.join(FRONTEND_DIST, "index.html"))


if __name__ == "__main__":
    import uvicorn
    port = int(os.environ.get("PORT", 8000))
    uvicorn.run("main:app", host="0.0.0.0", port=port, reload=True)
